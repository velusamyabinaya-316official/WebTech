// =====================================================
// LifeFlow Blood Bank – page scripts (DOM manipulation)
// =====================================================

/* ---------- Small helpers ---------- */
const $ = id => document.getElementById(id);

// Escape user text before putting it into innerHTML (prevents HTML injection)
function esc(text) {
  const d = document.createElement("div");
  d.textContent = text;
  return d.innerHTML;
}

// Toast notification: created, appended, then removed from the DOM
function toast(text, type = "success") {
  let box = $("toastBox");
  if (!box) {
    box = document.createElement("div");
    box.id = "toastBox";
    document.body.appendChild(box);
  }
  const t = document.createElement("div");
  t.className = "toast " + type;
  t.setAttribute("role", "status");
  t.textContent = text;
  box.appendChild(t);
  setTimeout(() => t.remove(), 3200);
}

/* ---------- Form date limits & validation helpers ---------- */
const today = new Date().toISOString().split("T")[0];
$("date").min = today;
$("dob").max = today;
$("lastdonation").max = today;

const pw = $("password");
const cf = $("confirm");
function checkMatch() {
  cf.setCustomValidity(pw.value !== cf.value ? "Passwords do not match" : "");
}
pw.addEventListener("input", checkMatch);
cf.addEventListener("input", checkMatch);

// "None of the above" should not be combined with other conditions
const boxes = document.querySelectorAll("input[name='conditions']");
boxes.forEach(b => b.addEventListener("change", () => {
  if (b.value === "none" && b.checked) {
    boxes.forEach(o => { if (o !== b) o.checked = false; });
  } else if (b.checked) {
    $("c5").checked = false;
  }
}));

/* =====================================================
   1. BLOOD STOCK  –  modify table cells dynamically
   ===================================================== */
const stockRows = document.querySelectorAll("#availability tbody tr");
const stockGroup = $("stockGroup");

// Fill the dropdown from the table itself (createElement + appendChild)
stockRows.forEach(row => {
  const group = row.cells[0].textContent.trim();
  const opt = document.createElement("option");
  opt.setAttribute("value", group);
  opt.textContent = group;
  stockGroup.appendChild(opt);
});

function getRow(group) {
  return Array.from(stockRows).find(r => r.cells[0].textContent.trim() === group);
}
function getStock(group) {
  return parseInt(getRow(group).cells[1].textContent, 10);
}
function statusFor(units) {
  if (units <= 5)  return ["critical", "Critical"];
  if (units <= 15) return ["low", "Low"];
  return ["high", "Adequate"];
}

function setStock(group, units) {
  const row = getRow(group);
  units = Math.max(0, units);
  row.cells[1].textContent = units;                    // modify units
  const [cls, label] = statusFor(units);               // modify status
  row.cells[2].className = cls;
  row.cells[2].textContent = label;

  row.classList.add("flash");                          // highlight changed row
  setTimeout(() => row.classList.remove("flash"), 1200);

  const now = new Date();                              // update "as of" date
  const time = $("stockTime");
  time.setAttribute("datetime", now.toISOString());
  time.textContent = now.toLocaleString("en-IN", { dateStyle: "long", timeStyle: "short" });
}

function readUnits() {
  const n = parseInt($("stockUnits").value, 10);
  if (isNaN(n) || n < 0) { toast("Enter a valid number of units.", "error"); return null; }
  return n;
}

$("stockAdd").addEventListener("click", () => {
  const n = readUnits(); if (n === null) return;
  const g = stockGroup.value;
  setStock(g, getStock(g) + n);
  toast(`Added ${n} unit(s) to ${g}.`);
});
$("stockIssue").addEventListener("click", () => {
  const n = readUnits(); if (n === null) return;
  const g = stockGroup.value;
  if (n > getStock(g)) { toast(`Only ${getStock(g)} unit(s) of ${g} in stock.`, "error"); return; }
  setStock(g, getStock(g) - n);
  toast(`Issued ${n} unit(s) of ${g}.`, "info");
});
$("stockSet").addEventListener("click", () => {
  const n = readUnits(); if (n === null) return;
  const g = stockGroup.value;
  setStock(g, n);
  toast(`${g} stock set to ${n}.`, "info");
});

/* =====================================================
   2. DONORS  –  add, display, modify, remove
   ===================================================== */
const STORE_KEY = "lifeflowDonors";
let donors = [];
try { donors = JSON.parse(localStorage.getItem(STORE_KEY)) || []; } catch (e) { donors = []; }
function saveDonors() {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(donors)); } catch (e) { /* storage unavailable */ }
}

const donorList = $("donorList");

// Returns a list of reasons why the donor needs a review (empty = eligible)
function eligibilityIssues(d) {
  const issues = [];
  if (d.weight < 50) issues.push("weight below 50 kg");
  if (d.haemoglobin !== null && d.haemoglobin < 12.5) issues.push("haemoglobin below 12.5");
  if (d.conditions.includes("surgery")) issues.push("recent surgery");
  if (d.conditions.includes("tattoo")) issues.push("recent tattoo/piercing");
  if (d.conditions.includes("diabetes") || d.conditions.includes("bp")) issues.push("medical condition to review");
  if (d.lastdonation) {
    const months = (Date.now() - new Date(d.lastdonation)) / (1000 * 60 * 60 * 24 * 30.44);
    const needed = d.gender === "female" ? 4 : 3;
    if (months < needed) issues.push(`last donation under ${needed} months ago`);
  }
  return issues;
}

function fillDetails(panel, d) {
  panel.innerHTML =
    `<p><strong>Email:</strong> ${esc(d.email)}</p>` +
    `<p><strong>Phone:</strong> ${esc(d.phone)}</p>` +
    `<p><strong>Weight:</strong> ${esc(String(d.weight))} kg &nbsp; <strong>Haemoglobin:</strong> ${d.haemoglobin !== null ? esc(String(d.haemoglobin)) + " g/dL" : "not given"}</p>` +
    `<p><strong>Preferred date:</strong> ${esc(d.donationdate)}</p>` +
    `<p><strong>Last donation:</strong> ${d.lastdonation ? esc(d.lastdonation) : "First-time donor"}</p>` +
    `<p><strong>Conditions:</strong> ${d.conditions.length ? esc(d.conditions.join(", ")) : "None"}</p>` +
    `<p><strong>Address:</strong> ${d.address ? esc(d.address) : "—"}</p>` +
    (d.notes ? `<p><strong>Notes:</strong> ${esc(d.notes)}</p>` : "");
}

function makeButton(text, cls) {
  const b = document.createElement("button");
  b.type = "button";
  b.textContent = text;
  if (cls) b.className = cls;
  return b;
}

// Build one donor card (<li>) with createElement / appendChild
function buildCard(d) {
  const li = document.createElement("li");
  li.className = "donor-card";
  li.setAttribute("data-id", d.id);

  const badge = document.createElement("span");
  badge.className = "badge";
  badge.textContent = d.bloodgroup;

  const info = document.createElement("div");
  info.className = "donor-info";

  const name = document.createElement("strong");
  name.className = "donor-name";
  name.textContent = d.name;

  const meta = document.createElement("span");
  meta.className = "donor-meta";
  meta.textContent = `${d.age} yrs • ${d.gender} • `;
  const phone = document.createElement("span");
  phone.textContent = d.phone;
  meta.appendChild(phone);

  const issues = eligibilityIssues(d);
  const tag = document.createElement("span");
  tag.className = "tag " + (d.donated ? "done" : issues.length ? "review" : "ok");
  tag.textContent = d.donated ? "Donated ✓" : issues.length ? "Review needed" : "Eligible";
  if (issues.length && !d.donated) tag.setAttribute("title", issues.join(", "));

  info.append(name, meta, tag);

  // Buttons
  const actions = document.createElement("div");
  actions.className = "donor-actions";
  const btnDetails = makeButton("Details", "btn-outline");
  const btnEdit    = makeButton("Edit", "btn-outline");
  const btnDonated = makeButton(d.donated ? "Donated ✓" : "Mark Donated");
  const btnRemove  = makeButton("Remove", "btn-dark");
  if (d.donated) btnDonated.setAttribute("disabled", "");
  actions.append(btnDetails, btnEdit, btnDonated, btnRemove);

  // Hidden details panel
  const panel = document.createElement("div");
  panel.className = "donor-details";
  panel.setAttribute("hidden", "");
  fillDetails(panel, d);

  const top = document.createElement("div");
  top.className = "donor-top";
  top.append(badge, info, actions);
  li.append(top, panel);

  // --- DISPLAY: show / hide details
  btnDetails.addEventListener("click", () => {
    const hidden = panel.hasAttribute("hidden");
    if (hidden) panel.removeAttribute("hidden"); else panel.setAttribute("hidden", "");
    btnDetails.textContent = hidden ? "Hide" : "Details";
  });

  // --- MODIFY: edit name and phone in place
  btnEdit.addEventListener("click", () => {
    if (btnEdit.textContent === "Edit") {
      const nameInput = document.createElement("input");
      nameInput.type = "text";
      nameInput.value = d.name;
      nameInput.className = "edit-input";
      nameInput.setAttribute("aria-label", "Edit name");
      const phoneInput = document.createElement("input");
      phoneInput.type = "tel";
      phoneInput.value = d.phone;
      phoneInput.className = "edit-input";
      phoneInput.setAttribute("aria-label", "Edit phone");
      name.replaceWith(nameInput);
      phone.replaceWith(phoneInput);
      btnEdit.textContent = "Save";
      nameInput.focus();
    } else {
      const nameInput = li.querySelector("input[aria-label='Edit name']");
      const phoneInput = li.querySelector("input[aria-label='Edit phone']");
      const newName = nameInput.value.trim();
      const newPhone = phoneInput.value.trim();
      if (!/^[A-Za-z .]{3,50}$/.test(newName)) { toast("Name: 3–50 letters, spaces or dots.", "error"); return; }
      if (!/^[6-9][0-9]{9}$/.test(newPhone))  { toast("Enter a valid 10-digit mobile number.", "error"); return; }
      d.name = newName;
      d.phone = newPhone;
      name.textContent = newName;
      phone.textContent = newPhone;
      nameInput.replaceWith(name);
      phoneInput.replaceWith(phone);
      fillDetails(panel, d);
      btnEdit.textContent = "Edit";
      saveDonors();
      toast("Donor details updated.");
    }
  });

  // --- MODIFY: mark donated -> also adds 1 unit to the stock table
  btnDonated.addEventListener("click", () => {
    d.donated = true;
    btnDonated.setAttribute("disabled", "");
    btnDonated.textContent = "Donated ✓";
    tag.className = "tag done";
    tag.textContent = "Donated ✓";
    tag.removeAttribute("title");
    setStock(d.bloodgroup, getStock(d.bloodgroup) + 1);
    saveDonors();
    toast(`Thank you, ${d.name}! +1 unit added to ${d.bloodgroup} stock.`);
  });

  // --- REMOVE: delete from array and from the DOM
  btnRemove.addEventListener("click", () => {
    if (!confirm(`Remove ${d.name} from the donor list?`)) return;
    donors = donors.filter(x => x.id !== d.id);
    saveDonors();
    li.classList.add("removing");
    setTimeout(() => { li.remove(); updateCount(); }, 250);
    toast("Donor removed.", "info");
  });

  return li;
}

function updateCount() {
  const shown = donorList.children.length;
  $("donorCount").textContent = donors.length;
  const empty = $("emptyMsg");
  if (shown === 0) {
    empty.textContent = donors.length ? "No donors match your search." : "No donors registered yet. Fill in the form above to add the first one.";
    empty.removeAttribute("hidden");
  } else {
    empty.setAttribute("hidden", "");
  }
}

function renderList() {
  const q = $("donorSearch").value.trim().toLowerCase();
  donorList.innerHTML = "";                          // clear old cards
  donors
    .filter(d => !q || d.name.toLowerCase().includes(q) || d.bloodgroup.toLowerCase().includes(q))
    .forEach(d => donorList.appendChild(buildCard(d)));
  updateCount();
}

// Live search
$("donorSearch").addEventListener("input", renderList);

// Clear all
$("clearAll").addEventListener("click", () => {
  if (!donors.length) { toast("The donor list is already empty.", "info"); return; }
  if (!confirm("Remove ALL registered donors?")) return;
  donors = [];
  saveDonors();
  renderList();
  toast("All donors removed.", "info");
});

/* ---------- ADD: registration form -> new donor card ---------- */
const form = $("donorForm");
const msg = $("msg");

form.addEventListener("submit", e => {
  e.preventDefault();
  const fd = new FormData(form);
  const phoneVal = fd.get("phone").trim();

  if (donors.some(x => x.phone === phoneVal)) {
    msg.textContent = "";
    toast("A donor with this phone number is already registered.", "error");
    return;
  }

  const donor = {
    id: Date.now(),
    name: fd.get("name").trim(),
    age: fd.get("age"),
    gender: fd.get("gender"),
    bloodgroup: fd.get("bloodgroup"),
    weight: parseFloat(fd.get("weight")),
    haemoglobin: fd.get("haemoglobin") ? parseFloat(fd.get("haemoglobin")) : null,
    lastdonation: fd.get("lastdonation"),
    conditions: fd.getAll("conditions"),
    notes: fd.get("notes").trim(),
    phone: phoneVal,
    email: fd.get("email").trim(),
    address: fd.get("address").trim(),
    donationdate: fd.get("donationdate"),
    donated: false
  };

  donors.push(donor);
  saveDonors();
  $("donorSearch").value = "";
  renderList();

  form.reset();                                      // reset first, then show message
  msg.textContent = `Thank you, ${donor.name}! Your registration was received.`;
  toast(`${donor.name} registered successfully.`);

  const card = donorList.lastElementChild;
  card.classList.add("new");
  $("donors").scrollIntoView({ behavior: "smooth", block: "start" });
});
form.addEventListener("reset", () => { msg.textContent = ""; });

renderList();                                        // show saved donors on load

/* =====================================================
   3. RESPONSIVE NAVIGATION  –  hamburger toggle
   ===================================================== */
const navToggle = $("navToggle");
const navMenu = $("navMenu");

navToggle.addEventListener("click", () => {
  const open = navMenu.classList.toggle("open");
  navToggle.setAttribute("aria-expanded", open);
  navToggle.innerHTML = open ? "&times;" : "&#9776;";
});

navMenu.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
  navMenu.classList.remove("open");
  navToggle.setAttribute("aria-expanded", "false");
  navToggle.innerHTML = "&#9776;";
}));