/* =========================================================
   LifeFlow Blood Bank – script.js
   Load AFTER the existing inline script (before </body>).
   ========================================================= */
document.documentElement.classList.add("js");

const $  = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

/* ---------- 1. Notification toast ---------- */
const toast = $("#toast");
let toastTimer;

function showToast(message, type = "", icon = "✅") {
  $("#toastText").textContent = message;
  $("#toastIcon").textContent = icon;
  toast.className = "toast " + type;       // reset so the animation can replay
  void toast.offsetWidth;                  // force reflow
  toast.classList.add("show");

  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3500);
}

/* ---------- 2. Stock cards built from the availability table ---------- */
const stockBox = $("#stockCards");
const stockBtn = $("#toggleCards");

function buildCards() {
  stockBox.innerHTML = "";
  $$("#availability tbody tr").forEach(row => {
  const [group, units, status] = $$("td", row);
  const pct = Math.min(100, (parseInt(units.textContent, 10) / 60) * 100);

  const card = document.createElement("div");
  card.className = "stock-card " + status.className;
  card.style.setProperty("--pct", pct + "%");
  card.innerHTML =
    `<span class="sc-group">${group.textContent}</span>` +
    `<strong>${units.textContent} units</strong>` +
    `<span class="sc-status">${status.textContent}</span>` +
    `<div class="bar"><span></span></div>`;
  stockBox.appendChild(card);
  });
  if (cardsOpen) $$(".stock-card", stockBox).forEach(c => c.classList.add("show"));
}

let cardsOpen = false;
buildCards();
stockBtn.addEventListener("click", () => {
  cardsOpen = !cardsOpen;
  stockBox.classList.toggle("open", cardsOpen);
  stockBtn.textContent = cardsOpen ? "Hide Stock Cards" : "Show Stock Cards";

  // Staggered reveal: each card appears 120 ms after the previous one
  $$(".stock-card", stockBox).forEach((card, i) => {
    setTimeout(() => card.classList.toggle("show", cardsOpen), cardsOpen ? i * 120 : 0);
  });
});

$("#alertBtn").addEventListener("click", () => {
  const urgent = $$("#availability td.critical").map(td => td.parentElement.firstElementChild.textContent);
  showToast("Urgent need: " + urgent.join(", ") + ". Donors with these groups are most needed.", "warn", "🔔");
});

/* ---------- 3. Accordion: open / close eligibility and guideline cards ---------- */
$$("#eligibility article, #guidelines article").forEach(article => {
  const heading = $("h3", article);
  const body = document.createElement("div");
  body.className = "acc-body";
  while (heading.nextSibling) body.appendChild(heading.nextSibling);
  article.appendChild(body);

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "acc-head";
  btn.setAttribute("aria-expanded", "true");
  btn.innerHTML = `<span>${heading.textContent}</span><span class="chev">▼</span>`;
  heading.textContent = "";
  heading.appendChild(btn);

  btn.addEventListener("click", () => {
    const closed = article.classList.toggle("collapsed");
    btn.setAttribute("aria-expanded", String(!closed));
  });
});

/* ---------- 4. Gallery image modal ---------- */
const modal = $("#lightbox");
const closeModal = () => modal.classList.remove("open");

$$(".gallery-item").forEach(item => {
  item.addEventListener("click", () => {
    const img = $("img", item);
    $("#lbImg").src = img.src;
    $("#lbImg").alt = img.alt;
    $("#lbCap").textContent = $("strong", item).textContent;
    modal.classList.add("open");
  });
});

$("#lbClose").addEventListener("click", closeModal);
modal.addEventListener("click", e => { if (e.target === modal) closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

/* =========================================================
   5. DONOR FORM: constraints, error messages, success message
   ========================================================= */
const donorForm = $("#donorForm");
const fields = $$("input, select, textarea", donorForm);
const formError = $("#formError");
const formMsg = $("#msg");

// Preferred donation date: today up to 60 days ahead
const lastDay = new Date();
lastDay.setDate(lastDay.getDate() + 60);
$("#date").max = lastDay.toISOString().split("T")[0];

// Live character counter for the notes box
const notes = $("#notes");
const counter = document.createElement("span");
counter.className = "counter";
notes.after(counter);
const updateCounter = () => { counter.textContent = notes.value.length + " / " + notes.maxLength; };
updateCounter();

const isGroup = el => el.type === "radio" || el.name === "conditions";
const keyOf = el => (isGroup(el) ? el.name : el.id);
const fmtDate = iso => new Date(iso).toLocaleDateString("en-IN");

function yearsSince(date) {
  const now = new Date();
  let years = now.getFullYear() - date.getFullYear();
  const beforeBirthday = now.getMonth() < date.getMonth() ||
    (now.getMonth() === date.getMonth() && now.getDate() < date.getDate());
  return beforeBirthday ? years - 1 : years;
}

/* Cross-field rules, written with setCustomValidity() */
function applyRules() {
  const age = $("#age"), dob = $("#dob"), don = $("#date"), last = $("#lastdonation");
  [age, dob, don, last].forEach(el => el.setCustomValidity(""));

  if (dob.value) {
    const years = yearsSince(new Date(dob.value));
    if (years < 18 || years > 65) {
      dob.setCustomValidity("Donors must be 18 to 65 years old (this date gives " + years + ").");
    } else if (age.value && Number(age.value) !== years) {
      age.setCustomValidity("Age does not match your date of birth (" + years + " years).");
    }
  }

  if (last.value && dob.value && new Date(last.value) < new Date(dob.value)) {
    last.setCustomValidity("Last donation cannot be before your date of birth.");
  }

  if (last.value && don.value) {
    const gender = donorForm.querySelector("input[name='gender']:checked");
    const months = gender && gender.value === "female" ? 4 : 3;
    const earliest = new Date(last.value);
    earliest.setMonth(earliest.getMonth() + months);
    if (new Date(don.value) < earliest) {
      don.setCustomValidity("Wait at least " + months + " months after your last donation. Earliest date: " +
        earliest.toLocaleDateString("en-IN") + ".");
    }
  }

  const surgery = $("#c3"), tattoo = $("#c4"), none = $("#c5");
  surgery.setCustomValidity(surgery.checked ? "Not eligible: please wait 6 months after major surgery." : "");
  tattoo.setCustomValidity(tattoo.checked ? "Not eligible: please wait 6 months after a tattoo or piercing." : "");
  none.setCustomValidity(donorForm.querySelector("input[name='conditions']:checked")
    ? "" : "Tick at least one option, or choose \u201CNone of the above\u201D.");

  const file = $("#idproof");
  file.setCustomValidity("");
  if (file.files[0]) {
    if (file.files[0].size > 2 * 1024 * 1024) file.setCustomValidity("File is too large. Maximum size is 2 MB.");
    else if (!/\.(jpe?g|png|pdf)$/i.test(file.files[0].name)) file.setCustomValidity("Only JPG, PNG or PDF files are accepted.");
  }
}

/* Turn the browser's validity flags into plain-language messages */
function friendly(el) {
  const v = el.validity;
  const lab = donorForm.querySelector("label[for='" + el.id + "']");
  const name = lab ? lab.textContent.replace("*", "").trim() : "This field";

  if (v.customError)    return el.validationMessage;
  if (v.valueMissing) {
    if (el.type === "radio")    return "Please select a gender.";
    if (el.id === "consent")    return "You must confirm the consent statement.";
    if (el.tagName === "SELECT") return "Please select your " + name.toLowerCase() + ".";
    return name + " is required.";
  }
  if (v.typeMismatch)   return "Enter a valid email address, for example name@example.com.";
  if (v.tooShort)       return name + " needs at least " + el.minLength + " characters.";
  if (v.tooLong)        return name + " can have at most " + el.maxLength + " characters.";
  if (v.rangeUnderflow) return el.type === "date" ? "Date cannot be before " + fmtDate(el.min) + "." : name + " must be at least " + el.min + ".";
  if (v.rangeOverflow)  return el.type === "date" ? "Date cannot be after " + fmtDate(el.max) + "." : name + " must be at most " + el.max + ".";
  if (v.stepMismatch)   return "Enter a valid number for " + name.toLowerCase() + ".";
  if (v.patternMismatch) return el.title || "The format is not valid.";
  return el.validationMessage;
}

/* One error <span> per field (or per radio / checkbox group), created on demand */
function errorSlot(el) {
  const id = "err-" + keyOf(el);
  let slot = document.getElementById(id);
  if (slot) return slot;

  slot = document.createElement("span");
  slot.id = id;
  slot.className = "field-error";
  slot.setAttribute("role", "alert");

  let host = el;
  if (isGroup(el)) host = el.parentElement;
  else if (el.type === "checkbox") host = donorForm.querySelector("label[for='" + el.id + "']");
  host.after(slot);
  return slot;
}

function showError(el) {
  const slot = errorSlot(el);
  const members = isGroup(el) ? $$("[name='" + el.name + "']", donorForm) : [el];
  const bad = members.find(m => !m.validity.valid);

  slot.textContent = bad ? friendly(bad) : "";
  members.forEach(m => {
    m.classList.add("touched");
    m.setAttribute("aria-invalid", bad ? "true" : "false");
    m.setAttribute("aria-describedby", slot.id);
  });
}

const refreshTouched = () => fields.filter(f => f.classList.contains("touched")).forEach(showError);

function clearErrors() {
  fields.forEach(f => { f.classList.remove("touched"); f.removeAttribute("aria-invalid"); });
  $$(".field-error", donorForm).forEach(slot => { slot.textContent = ""; });
  formError.textContent = "";
}

/* Live validation: after a field is touched, keep its message up to date */
["input", "change"].forEach(type => donorForm.addEventListener(type, e => {
  applyRules();
  updateCounter();
  if (e.target.classList.contains("touched") || type === "change") showError(e.target);
  refreshTouched();
}));
donorForm.addEventListener("focusout", e => {
  if (e.target.matches("input, select, textarea")) { applyRules(); showError(e.target); }
});

// "invalid" does not bubble, so listen in the capture phase (shake animation)
donorForm.addEventListener("invalid", e => {
  e.target.classList.add("shake");
  setTimeout(() => e.target.classList.remove("shake"), 500);
}, true);

/* Submit: validate everything, then show errors or a success message */
donorForm.addEventListener("submit", e => {
  e.preventDefault();
  applyRules();
  formMsg.textContent = "";

  if (!donorForm.checkValidity()) {
    fields.forEach(showError);
    const bad = fields.filter(f => !f.validity.valid);
    const count = new Set(bad.map(keyOf)).size;
    formError.textContent = "Please fix " + count + " highlighted field" + (count === 1 ? "" : "s") + " before registering.";
    bad[0].focus();
    bad[0].reportValidity();                  // native bubble on the first problem
    showToast("The form has errors. Please check the highlighted fields.", "warn", "\u26A0\uFE0F");
    return;
  }

  const name = $("#name").value.trim();
  const when = fmtDate($("#date").value);
  const ref  = "LF-" + Date.now().toString().slice(-6);

  donorForm.reset();                          // also fires the "reset" handler below
  formMsg.textContent = "Success! Thank you, " + name + ". Your donor registration (reference " + ref +
                        ") is confirmed for " + when + ".";

  const btn = $("button[type='submit']", donorForm);
  btn.classList.add("done");
  setTimeout(() => btn.classList.remove("done"), 900);
  showToast("Registration received. Thank you for donating!");
});

donorForm.addEventListener("reset", () => {
  clearErrors();
  setTimeout(() => { applyRules(); updateCounter(); }, 0);
});

applyRules();

/* ---------- 6. Back-to-top shows after scrolling ---------- */
const topBtn = $(".back-to-top");
const onScroll = () => topBtn.classList.toggle("show", window.scrollY > 300);
window.addEventListener("scroll", onScroll, { passive: true });
onScroll();


/* =========================================================
   7. BLOOD REQUEST MANAGER – add, modify, display, remove
   ========================================================= */
const reqList  = document.getElementById("requestList");
const reqMsg   = document.getElementById("mgrMsg");
const reqCount = document.getElementById("reqCount");
const norm = text => text.replace("\u2212", "-").toUpperCase();
let reqId = 0;

function setMsg(text, type) {
  reqMsg.textContent = text;
  reqMsg.setAttribute("data-type", type || "ok");
}

/* Display: summary counter and empty-state note */
function updateCount() {
  const items = $$(".req-item", reqList);
  const units = items.reduce((sum, li) => sum + Number(li.dataset.units), 0);
  reqCount.textContent = items.length + (items.length === 1 ? " request, " : " requests, ") + units + " units needed";

  let empty = document.getElementById("emptyNote");
  if (!items.length && !empty) {
    empty = document.createElement("p");
    empty.id = "emptyNote";
    empty.className = "empty-note";
    empty.textContent = "No open requests. Add one using the form above.";
    reqList.after(empty);
  } else if (items.length && empty) {
    empty.remove();
  }
}

/* Draws one <li> from its data-* attributes (view mode or edit mode) */
function render(li) {
  const editing = li.classList.contains("editing");
  const done = li.dataset.status === "fulfilled";

  const info = editing
    ? '<input type="text" class="edit-name" maxlength="40" aria-label="Name">' +
      '<input type="number" class="edit-units" min="1" max="20" aria-label="Units">'
    : '<strong class="req-name"></strong><span class="req-units"></span>';

  const actions = editing
    ? '<button type="button" class="mini ok save">Save</button><button type="button" class="mini cancel">Cancel</button>'
    : done
      ? '<button type="button" class="mini del">Remove</button>'
      : '<button type="button" class="mini edit">Edit</button>' +
        '<button type="button" class="mini ok fulfil">Fulfil</button>' +
        '<button type="button" class="mini del">Remove</button>';

  li.innerHTML = '<span class="req-group"></span><div class="req-info">' + info +
                 '</div><div class="req-actions">' + actions + '</div>';

  // User text goes in through textContent / value, never innerHTML
  li.querySelector(".req-group").textContent = li.dataset.group;
  if (editing) {
    li.querySelector(".edit-name").value  = li.dataset.name;
    li.querySelector(".edit-units").value = li.dataset.units;
  } else {
    li.querySelector(".req-name").textContent = li.dataset.name;
    li.querySelector(".req-units").textContent =
      done ? "Fulfilled: " + li.dataset.units + " units supplied"
           : li.dataset.units + (li.dataset.units === "1" ? " unit" : " units") + " needed";
  }
}

/* Add */
function addRequest(name, group, units) {
  const li = document.createElement("li");
  li.className = "req-item";
  li.id = "req" + (++reqId);
  li.setAttribute("data-name", name);
  li.setAttribute("data-group", group);
  li.setAttribute("data-units", units);
  li.setAttribute("data-status", "open");
  render(li);
  reqList.appendChild(li);
  updateCount();
}

/* Keep the availability table in step with fulfilled requests */
function updateStatus(row) {
  const units = parseInt(row.children[1].textContent, 10);
  const cls = units <= 5 ? "critical" : units <= 15 ? "low" : "high";
  row.children[2].className = cls;
  row.children[2].textContent = { critical: "Critical", low: "Low", high: "Adequate" }[cls];
}

function fulfil(li) {
  const row = $$("#availability tbody tr").find(r => norm(r.firstElementChild.textContent) === norm(li.dataset.group));
  const stock = parseInt(row.children[1].textContent, 10);
  const need = Number(li.dataset.units);

  if (stock < need) {
    setMsg("Only " + stock + " units of " + li.dataset.group + " in stock; " + need + " needed.", "error");
    showToast("Not enough " + li.dataset.group + " stock to fulfil this request.", "warn", "⚠️");
    return;
  }
  row.children[1].textContent = stock - need;   // modify the table
  updateStatus(row);
  buildCards();
  li.setAttribute("data-status", "fulfilled");
  render(li);
  setMsg("Request for " + li.dataset.name + " fulfilled. Stock updated.", "ok");
  showToast(li.dataset.group + " stock is now " + (stock - need) + " units.");
}

/* Add button (Enter in the name box also adds) */
function handleAdd() {
  const nameBox = document.getElementById("reqName");
  const name  = nameBox.value.trim();
  const group = document.getElementById("reqGroup").value;
  const units = parseInt(document.getElementById("reqUnits").value, 10);

  if (name.length < 3)         { setMsg("Enter a hospital or patient name (at least 3 characters).", "error"); nameBox.focus(); return; }
  if (!group)                  { setMsg("Choose a blood group.", "error"); return; }
  if (!(units >= 1 && units <= 20)) { setMsg("Enter units between 1 and 20.", "error"); return; }

  addRequest(name, group, units);
  nameBox.value = "";
  document.getElementById("reqGroup").value = "";
  document.getElementById("reqUnits").value = "";
  setMsg("Request added for " + name + ".", "ok");
  showToast("New " + group + " request added.");
  nameBox.focus();
}
document.getElementById("addReqBtn").addEventListener("click", handleAdd);
document.getElementById("reqName").addEventListener("keydown", e => { if (e.key === "Enter") handleAdd(); });

/* Modify / remove / fulfil: one listener on the list (event delegation) */
reqList.addEventListener("click", e => {
  const btn = e.target.closest("button");
  if (!btn) return;
  const li = btn.closest(".req-item");

  if (btn.classList.contains("del")) {
    li.classList.add("leaving");
    setTimeout(() => {
      li.remove();                              // remove from the DOM
      updateCount();
      setMsg("Request removed.", "warn");
    }, 350);
  } else if (btn.classList.contains("edit")) {
    li.classList.add("editing");
    render(li);
    li.querySelector(".edit-name").focus();
  } else if (btn.classList.contains("cancel")) {
    li.classList.remove("editing");
    render(li);
  } else if (btn.classList.contains("save")) {
    const name  = li.querySelector(".edit-name").value.trim();
    const units = parseInt(li.querySelector(".edit-units").value, 10);
    if (name.length < 3 || !(units >= 1 && units <= 20)) {
      setMsg("Name needs 3+ characters and units must be 1 to 20.", "error");
      return;
    }
    li.setAttribute("data-name", name);
    li.setAttribute("data-units", units);
    li.classList.remove("editing");
    render(li);
    updateCount();
    setMsg("Request updated.", "ok");
  } else if (btn.classList.contains("fulfil")) {
    fulfil(li);
  }
});

/* Display: live filter by blood group or name */
document.getElementById("reqFilter").addEventListener("input", e => {
  const q = norm(e.target.value.trim());
  $$(".req-item", reqList).forEach(li => {
    const match = !q || norm(li.dataset.group).includes(q) || li.dataset.name.toUpperCase().includes(q);
    li.classList.toggle("hidden", !match);
  });
});

/* Clear all */
document.getElementById("clearReqBtn").addEventListener("click", () => {
  reqList.innerHTML = "";
  updateCount();
  setMsg("All requests cleared.", "warn");
});

/* Starting data */
addRequest("Riverside Hospital", "O\u2212", 4);
addRequest("City Hospital", "A+", 2);
addRequest("Green Valley Clinic", "B+", 1);