// ===== LifeFlow Blood Bank – page scripts =====

// Date limits: donation date from today onwards; birth / last-donation dates not in the future
const today = new Date().toISOString().split("T")[0];
document.getElementById("date").min = today;
document.getElementById("dob").max = today;
document.getElementById("lastdonation").max = today;

// Confirm-password check (HTML5 constraint validation API)
const pw = document.getElementById("password");
const cf = document.getElementById("confirm");
function checkMatch() {
  cf.setCustomValidity(pw.value !== cf.value ? "Passwords do not match" : "");
}
pw.addEventListener("input", checkMatch);
cf.addEventListener("input", checkMatch);

// "None of the above" should not be combined with other conditions
const boxes = document.querySelectorAll("input[name='conditions']");
boxes.forEach(b => b.addEventListener("change", () => {
  if (b.value === "none" && b.checked) {
    boxes.forEach(o => { if (o !== b) o.checked = false; });
  } else if (b.checked) {
    document.getElementById("c5").checked = false;
  }
}));

// Demo submit: show a message instead of sending data
const form = document.getElementById("donorForm");
const msg = document.getElementById("msg");
form.addEventListener("submit", e => {
  e.preventDefault();
  msg.textContent =
    "Thank you, " + document.getElementById("name").value + "! Your registration was received.";
  form.reset();
  msg.scrollIntoView({ behavior: "smooth", block: "center" });
});
form.addEventListener("reset", () => { msg.textContent = ""; });

// ===== Responsive navigation: hamburger toggle =====
const navToggle = document.getElementById("navToggle");
const navMenu = document.getElementById("navMenu");

navToggle.addEventListener("click", () => {
  const open = navMenu.classList.toggle("open");
  navToggle.setAttribute("aria-expanded", open);
  navToggle.innerHTML = open ? "&times;" : "&#9776;";
});

// Close the menu after a link is tapped (mobile)
navMenu.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
  navMenu.classList.remove("open");
  navToggle.setAttribute("aria-expanded", "false");
  navToggle.innerHTML = "&#9776;";
}));