/* =========================================================
   LifeFlow Blood Bank – script.js
   Load AFTER the existing inline script (before </body>).
   ========================================================= */
document.documentElement.classList.add("js");

const $  = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

/* ---------- 1. Notification toast ---------- */
const toast = $("#toast");
let toastTimer;

function showToast(message, type = "", icon = "✅") {
  $("#toastText").textContent = message;
  $("#toastIcon").textContent = icon;
  toast.className = "toast " + type;       // reset so the animation can replay
  void toast.offsetWidth;                  // force reflow
  toast.classList.add("show");

  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3500);
}

/* ---------- 2. Stock cards built from the availability table ---------- */
const stockBox = $("#stockCards");
const stockBtn = $("#toggleCards");

$$("#availability tbody tr").forEach(row => {
  const [group, units, status] = $$("td", row);
  const pct = Math.min(100, (parseInt(units.textContent, 10) / 60) * 100);

  const card = document.createElement("div");
  card.className = "stock-card " + status.className;
  card.style.setProperty("--pct", pct + "%");
  card.innerHTML =
    `<span class="sc-group">${group.textContent}</span>` +
    `<strong>${units.textContent} units</strong>` +
    `<span class="sc-status">${status.textContent}</span>` +
    `<div class="bar"><span></span></div>`;
  stockBox.appendChild(card);
});

let cardsOpen = false;
stockBtn.addEventListener("click", () => {
  cardsOpen = !cardsOpen;
  stockBox.classList.toggle("open", cardsOpen);
  stockBtn.textContent = cardsOpen ? "Hide Stock Cards" : "Show Stock Cards";

  // Staggered reveal: each card appears 120 ms after the previous one
  $$(".stock-card", stockBox).forEach((card, i) => {
    setTimeout(() => card.classList.toggle("show", cardsOpen), cardsOpen ? i * 120 : 0);
  });
});

$("#alertBtn").addEventListener("click", () => {
  const urgent = $$("#availability td.critical").map(td => td.parentElement.firstElementChild.textContent);
  showToast("Urgent need: " + urgent.join(", ") + ". Donors with these groups are most needed.", "warn", "🔔");
});

/* ---------- 3. Accordion: open / close eligibility and guideline cards ---------- */
$$("#eligibility article, #guidelines article").forEach(article => {
  const heading = $("h3", article);
  const body = document.createElement("div");
  body.className = "acc-body";
  while (heading.nextSibling) body.appendChild(heading.nextSibling);
  article.appendChild(body);

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "acc-head";
  btn.setAttribute("aria-expanded", "true");
  btn.innerHTML = `<span>${heading.textContent}</span><span class="chev">▼</span>`;
  heading.textContent = "";
  heading.appendChild(btn);

  btn.addEventListener("click", () => {
    const closed = article.classList.toggle("collapsed");
    btn.setAttribute("aria-expanded", String(!closed));
  });
});

/* ---------- 4. Gallery image modal ---------- */
const modal = $("#lightbox");
const closeModal = () => modal.classList.remove("open");

$$(".gallery-item").forEach(item => {
  item.addEventListener("click", () => {
    const img = $("img", item);
    $("#lbImg").src = img.src;
    $("#lbImg").alt = img.alt;
    $("#lbCap").textContent = $("strong", item).textContent;
    modal.classList.add("open");
  });
});

$("#lbClose").addEventListener("click", closeModal);
modal.addEventListener("click", e => { if (e.target === modal) closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

/* ---------- 5. Form feedback ---------- */
const donorForm = $("#donorForm");

// "invalid" does not bubble, so listen in the capture phase
donorForm.addEventListener("invalid", e => {
  e.target.classList.add("shake");
  setTimeout(() => e.target.classList.remove("shake"), 500);
}, true);

// "submit" only fires when every field is valid
donorForm.addEventListener("submit", () => {
  const btn = $("button[type='submit']", donorForm);
  btn.classList.add("done");
  setTimeout(() => btn.classList.remove("done"), 900);
  showToast("Registration received. Thank you for donating!");
});

/* ---------- 6. Back-to-top shows after scrolling ---------- */
const topBtn = $(".back-to-top");
const onScroll = () => topBtn.classList.toggle("show", window.scrollY > 300);
window.addEventListener("scroll", onScroll, { passive: true });
onScroll();